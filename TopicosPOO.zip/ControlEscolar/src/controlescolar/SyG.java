package controlescolar;

/**
 *
 * @author Kevin
 */
public class SyG {
    
    private String NControl;
    private String Nombre;
    private String AP; //Apellido Paterno
    private String AM; //Apellido Materno
    private String RFC;
    private String FNA; //Fecha Nacimiento Año
    private String FNM; //Fecha Nacimiento Mes
    private String FND; //Fecha Nacimiento Dia
    private String Carrera;
    
    public String getNumControl(){
        return NControl;
    }
    public String setNumControl(){
        return NControl;
    }
    public String getNombre(){
        return Nombre;
    }
    public String setNombre(){
        return Nombre;
    }
    public String getApellidoP(){
        return AP;
    }
    public String setApellidoP(){
        return AP;
    }
    public String getApellidoM(){
        return AM;
    }
    public String setApellidoM(){
        return AM;
    }
    public String getRFC(){
        return RFC;
    }
    public String setRFC(){
        return RFC;
    }
    public String getFechaAnio(){
        return FNA;
    }
    public String setFechaAnio(){
        return FNA;
    }
    public String getFechaMes(){
        return FNM;
    }
    public String setFechaMes(){
        return FNM;
    }
    public String getFechaDia(){
        return FND;
    }
    public String setFechaDia(){
        return FND;
    }
    public String getCarrera(){
        return Carrera;
    }
    public String setCarrera(){
        return Carrera;
    }
    
}
