package registroinfo;

public class RegistroInfo {


    
}
