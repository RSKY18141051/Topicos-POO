package registroinfo;
import java.io.Serializable;

public class Tarjeta implements Serializable{
    private int numero;
    private String descripcion;
    private int existencia;
    private int stock_minimo;
    private int stock_maximo;
    
    public Tarjeta(int n, String d, int e, int smin, int smax){
        numero=n;
        descripcion=d;
        existencia=e;
        stock_minimo=smin;
        stock_maximo=smax;       
    }

    public void setNumero(int n) {
        numero=n;
    }

    public void setDescripcion(String d) {
        descripcion=d;
    }

    public void setExistencia(int e) {
        existencia=e;
    }

    public void setStock_minimo(int smin) {
        stock_minimo=smin;
    }

    public void setStock_maximo(int smax) {
        stock_maximo=smax;
    }

    public int getNumero() {
        return numero;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getExistencia() {
        return existencia;
    }

    public int getStock_minimo() {
        return stock_minimo;
    }

    public int getStock_maximo() {
        return stock_maximo;
    }
    
    
    
}
