public class ACalumno {
    public static void main(String [] args){
        frmRegistro registro = new frmRegistro();
        registro.setVisible(true);
    }
}
