public class CalumnoITQCarrera {
 private String carrera="";


    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }
 
    public String toString(){
        String mensaje=carrera;
        return mensaje;
    }
}
