public class CalumnoITQ {
 private String nc;

    public String getNc() {
        return nc;
    }

    public void setNc(String nc) {
        this.nc = nc;
    }
 
 public String toString(){
    String mensaje=nc;
     return mensaje;
}
}
