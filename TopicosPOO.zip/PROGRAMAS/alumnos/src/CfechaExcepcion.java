
public class CfechaExcepcion extends Exception{
  public CfechaExcepcion(String mensaje){
      super (mensaje);
  }  
}
