/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ContaZorrosA;

/**
 *
 * @author Kevin
 */
public class ClaseA {
    public int atributo_x=1;
    public int metodo_x(){
        return atributo_x*10;
    }
    public int metodo_y(){
        return atributo_x*100;
    }
    protected void finalize()throws Throwable{
        System.out.println("recursos liberados de la claseA");
    }
}
