package ContaZorrosA;
import javax.swing.JOptionPane;
/**
 *
 * @author Kevin
 */
public class NewJFrame extends javax.swing.JFrame {
    
    public NewJFrame() {
        initComponents();
        btn_asientocont.setVisible(false);
    }
    
    String salida="";
    Ccuenta cuenta[]=new Ccuenta[14];
    private int limite;
    int contadorCuenta=0;

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        lblsalida = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jta_salida = new javax.swing.JTextArea();
        txt_cvecuenta = new javax.swing.JTextField();
        txt_nombre = new javax.swing.JTextField();
        txt_tipocuenta = new javax.swing.JTextField();
        txt_saldo = new javax.swing.JTextField();
        jcb_tipo = new javax.swing.JComboBox<>();
        btn_datos = new javax.swing.JButton();
        btn_crear = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        btn_balance = new javax.swing.JButton();
        btn_asientocont = new javax.swing.JButton();
        btn_limpia = new javax.swing.JButton();
        btn_orden = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        jLabel1.setFont(new java.awt.Font("Consolas", 1, 36)); // NOI18N
        jLabel1.setText("Sistema de contabilidad Zorros A.C.");

        jLabel2.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel2.setText("CUENTAS T'S");

        jLabel3.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        jLabel3.setText("Clave de cuenta");

        jLabel4.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        jLabel4.setText("Nombre/Descripción");

        jLabel5.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        jLabel5.setText("Tipo de cuenta");

        jLabel6.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        jLabel6.setText("Saldo");

        lblsalida.setFont(new java.awt.Font("Consolas", 3, 18)); // NOI18N
        lblsalida.setText("ERRORES");

        jta_salida.setEditable(false);
        jta_salida.setColumns(20);
        jta_salida.setRows(5);
        jScrollPane1.setViewportView(jta_salida);

        txt_cvecuenta.setFont(new java.awt.Font("Consolas", 2, 18)); // NOI18N
        txt_cvecuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_cvecuentaActionPerformed(evt);
            }
        });

        txt_nombre.setFont(new java.awt.Font("Consolas", 2, 18)); // NOI18N

        txt_tipocuenta.setEditable(false);
        txt_tipocuenta.setFont(new java.awt.Font("Consolas", 2, 18)); // NOI18N

        txt_saldo.setFont(new java.awt.Font("Consolas", 2, 18)); // NOI18N
        txt_saldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_saldoActionPerformed(evt);
            }
        });

        jcb_tipo.setFont(new java.awt.Font("Consolas", 0, 18)); // NOI18N
        jcb_tipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Pasivo", "Capital" }));
        jcb_tipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcb_tipoActionPerformed(evt);
            }
        });

        btn_datos.setFont(new java.awt.Font("Consolas", 0, 18)); // NOI18N
        btn_datos.setText("ver datos");
        btn_datos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_datosActionPerformed(evt);
            }
        });

        btn_crear.setFont(new java.awt.Font("Consolas", 0, 18)); // NOI18N
        btn_crear.setText("Crear Objeto");
        btn_crear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_crearActionPerformed(evt);
            }
        });

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenxd/richter.png"))); // NOI18N

        btn_balance.setFont(new java.awt.Font("Consolas", 0, 18)); // NOI18N
        btn_balance.setText("Balance");
        btn_balance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_balanceActionPerformed(evt);
            }
        });

        btn_asientocont.setFont(new java.awt.Font("Consolas", 0, 18)); // NOI18N
        btn_asientocont.setText("Asientos Contables");
        btn_asientocont.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_asientocontActionPerformed(evt);
            }
        });

        btn_limpia.setFont(new java.awt.Font("Consolas", 0, 18)); // NOI18N
        btn_limpia.setText("Limpiar");
        btn_limpia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_limpiaActionPerformed(evt);
            }
        });

        btn_orden.setFont(new java.awt.Font("Consolas", 0, 18)); // NOI18N
        btn_orden.setText("Ordenar");
        btn_orden.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ordenActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(292, 292, 292)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_tipocuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_saldo, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jcb_tipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_crear))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(57, 57, 57)
                                .addComponent(btn_balance, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_limpia, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_orden, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(112, 112, 112))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblsalida)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(29, 29, 29)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel4)
                                        .addComponent(jLabel5)
                                        .addComponent(jLabel6))
                                    .addGap(38, 38, 38)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txt_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel2)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(txt_cvecuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(45, 45, 45)
                                            .addComponent(btn_datos)))
                                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addGap(0, 0, Short.MAX_VALUE))))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 448, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(33, 33, 33)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel8)
                                .addComponent(btn_asientocont))
                            .addGap(34, 34, 34)))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txt_cvecuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_datos))
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txt_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txt_tipocuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jcb_tipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btn_crear)))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txt_saldo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(btn_limpia)
                                .addGap(18, 18, 18)
                                .addComponent(btn_orden)
                                .addGap(18, 18, 18)
                                .addComponent(btn_asientocont))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(194, 194, 194)
                        .addComponent(btn_balance)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addComponent(lblsalida)
                .addGap(53, 53, 53)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(57, 57, 57))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void txt_cvecuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_cvecuentaActionPerformed
        
    // TODO add your handling code here:
    }//GEN-LAST:event_txt_cvecuentaActionPerformed
    
    
    private void jcb_tipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcb_tipoActionPerformed
        // TODO add your handling code here:
        txt_tipocuenta.setText(jcb_tipo.getSelectedItem()+"");
    }//GEN-LAST:event_jcb_tipoActionPerformed

    private void btn_crearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_crearActionPerformed
        String tipo=txt_tipocuenta.getText();
       try{
            
        if(tipo.equals("Activo")){
            cuenta[limite]=new CcuentaActivo();
            cuenta[limite].setCve_cuenta(txt_cvecuenta.getText());
           cuenta[limite].setNombre(txt_nombre.getText());
            cuenta[limite].setTipo_cuenta(txt_tipocuenta.getText());
            cuenta[limite].setSaldo(Double.parseDouble(txt_saldo.getText()));
           lblsalida.setText("Objeto creado en la posición "+limite);
           salida+=contadorCuenta+".- Clave "+cuenta[contadorCuenta].getCve_cuenta()+", Nombre "+cuenta[contadorCuenta].getNombre()+", Saldo $ "+cuenta[contadorCuenta].getSaldo()+"\n";
           contadorCuenta++;
        }
        if(tipo.equals("Pasivo")){
            cuenta[limite]=new CcuentaPasivo();
            cuenta[limite].setCve_cuenta(txt_cvecuenta.getText());
          cuenta[limite].setNombre(txt_nombre.getText());
            cuenta[limite].setTipo_cuenta(txt_tipocuenta.getText());
            cuenta[limite].setSaldo(Double.parseDouble(txt_saldo.getText()));
            lblsalida.setText("Objeto creado en la posición "+limite);
            salida+=contadorCuenta+".- Clave "+cuenta[contadorCuenta].getCve_cuenta()+", Nombre "+cuenta[contadorCuenta].getNombre()+", Saldo $ "+cuenta[contadorCuenta].getSaldo()+"\n";
           contadorCuenta++;
        }
        if(tipo.equals("Capital")){
            cuenta[limite]=new CcuentaCapital();
            cuenta[limite].setCve_cuenta(txt_cvecuenta.getText());
            cuenta[limite].setNombre(txt_nombre.getText());
            cuenta[limite].setTipo_cuenta(txt_tipocuenta.getText());
            cuenta[limite].setSaldo(Double.parseDouble(txt_saldo.getText()));
            lblsalida.setText("Objeto creado en la posición "+limite);
            salida+=contadorCuenta+".- Clave "+cuenta[contadorCuenta].getCve_cuenta()+", Nombre "+cuenta[contadorCuenta].getNombre()+", Saldo $ "+cuenta[contadorCuenta].getSaldo()+"\n";
           contadorCuenta++;
        }
        limite++;
       }
        catch(NumberFormatException f){
            lblsalida.setText("Clabe/Saldo debe de ser numerico");
        }
        catch(ArrayIndexOutOfBoundsException l){
            lblsalida.setText("Limite de arreglos excedidio");
        }
       catch(ContaException o){
            lblsalida.setText(o.getMessage());
        }
       
        jta_salida.setText(salida); 
    }//GEN-LAST:event_btn_crearActionPerformed

    private void btn_datosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_datosActionPerformed
        contadorCuenta=0;
        salida="";
        
        while (contadorCuenta<limite){
            salida+=contadorCuenta+".- Clave "+cuenta[contadorCuenta].getCve_cuenta()+", Nombre "+cuenta[contadorCuenta].getNombre()+", Saldo $ "+cuenta[contadorCuenta].getSaldo()+"\n";
            jta_salida.setText(salida);
            contadorCuenta++;
        }
    }//GEN-LAST:event_btn_datosActionPerformed

    private void btn_balanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_balanceActionPerformed
        int contador=0;
        double totalPasivo=0;
        double totalActivo=0;
        double totalCapital=0;

        btn_asientocont.setVisible(true);
        
        while(contador<limite){
            if(cuenta[contador].getTipo_cuenta().equals("Activo")){
                totalActivo+=cuenta[contador].getSaldo();
                salida+=cuenta[contador].toString();
            }
            if(cuenta[contador].getTipo_cuenta().equals("Pasivo")){
                totalPasivo+=cuenta[contador].getSaldo();
                salida+=cuenta[contador].toString();
            }
            if(cuenta[contador].getTipo_cuenta().equals("Capital")){
                totalCapital+=cuenta[contador].getSaldo();
                salida+=cuenta[contador].toString();
            }
            contador++;
        }
       
        salida+="\nActivo "+totalActivo+"\n";
        salida+="\nPasivo "+totalPasivo+"\n";
        salida+="\nCapital "+totalCapital+"\n";
        if(totalActivo==(totalPasivo+totalCapital)){
            salida="\nEl balance es correto\n";
            salida+="\nHay $"+totalActivo+" en activo y $"+(totalPasivo+totalCapital)+" en pasivo";
        }
        else{
            salida="El balance NO es correcto\n";
            salida+="\nHay $"+totalActivo+" en activo y $"+(totalPasivo+totalCapital)+" en pasivo";
        }
        jta_salida.setText(salida);
    }//GEN-LAST:event_btn_balanceActionPerformed

    private void txt_saldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_saldoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_saldoActionPerformed

    private void btn_asientocontActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_asientocontActionPerformed
       double balance=0;
       double cantidadHaber=0;
       double cantidadDebe=0;
       double total=0;
       String clave="";
       String salida="";
        int n=0;
        int r=JOptionPane.showConfirmDialog(null,"Cuenta de haber? (''No'' para debe)");
        while((n<10)&& (r!=2)){
            if(r==0){
            clave=JOptionPane.showInputDialog("Ingresa tu Clave: ");
            for(int c=0;c<10;c++){
                if(cuenta[c].getCve_cuenta().equals(clave)){
                    cantidadHaber+=cuenta[c].getSaldo();
                    total=total+cuenta[c].getSaldo();
                    lblsalida.setText("Cantidad de Haber $"+cantidadHaber);
                }
            } 
        }
        if (r==1){
           clave=JOptionPane.showInputDialog("Ingresa tu Clave: ");
            for(int i=0;i<10;i++){
                if(cuenta[i].getCve_cuenta().equals(clave)){
                    cantidadDebe+=cuenta[i].getSaldo();
                    total=total-cuenta[i].getSaldo();
                    lblsalida.setText("Cantidad de Debe $"+cantidadDebe);
                }
            } 
        }
           r=JOptionPane.showConfirmDialog(null,"Es una cuenta de haber?");
           n++;
       } 
       balance=cantidadHaber-cantidadDebe;
       if(balance==0){
           salida+="El balance cuadre y es: "+cantidadDebe;
       }else{
           salida+="El balance es incorrecto, no cuadra, hay: "+cantidadHaber+" y se debe: $"+cantidadDebe;
       }
       jta_salida.setText(salida);  
    
    }//GEN-LAST:event_btn_asientocontActionPerformed

    private void btn_limpiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_limpiaActionPerformed
        txt_nombre.setText("");
        txt_cvecuenta.setText("");
        txt_saldo.setText("");
        txt_tipocuenta.setText("");
        jta_salida.setText("");
    }//GEN-LAST:event_btn_limpiaActionPerformed

    private void btn_ordenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ordenActionPerformed
        //ordenate sesamo;
         jta_salida.setText("");
        Ccuenta ord=new Ccuenta();
        String[] nomOrden = ord.ordenburbuja(limite, cuenta);
        String salida="";
        salida+="Cuentas ordenadas:\n";
        String [] claOrden=new String[14]; //Ordenar Claves
        String [] salOrden=new String[14];
        for(int i=0;i<14;i++){ //Sera para mirar nOrden
            for(int k=0;k<14;k++){
                if(nomOrden[i].equals(cuenta[k].getNombre())){
                    claOrden[i]=cuenta[k].getCve_cuenta();
                    salOrden[i]=String.valueOf(cuenta[k].getSaldo());
                }                
            }
        }
        for(int i=0;i<14;i++){
             salida+=i+"   Clave: ["+claOrden[i]+"] Nombre ["+ nomOrden[i] +"] Saldo ["+salOrden[i]+"]\n";            
        }
        jta_salida.setText(salida);
    }//GEN-LAST:event_btn_ordenActionPerformed

    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_asientocont;
    private javax.swing.JButton btn_balance;
    private javax.swing.JButton btn_crear;
    private javax.swing.JButton btn_datos;
    private javax.swing.JButton btn_limpia;
    private javax.swing.JButton btn_orden;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> jcb_tipo;
    private javax.swing.JTextArea jta_salida;
    private javax.swing.JLabel lblsalida;
    private javax.swing.JTextField txt_cvecuenta;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JTextField txt_saldo;
    private javax.swing.JTextField txt_tipocuenta;
    // End of variables declaration//GEN-END:variables
}
