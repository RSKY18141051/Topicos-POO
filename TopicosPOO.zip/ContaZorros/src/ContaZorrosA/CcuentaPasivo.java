/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ContaZorrosA;

/**
 *
 * @author Kevin
 */
public class CcuentaPasivo extends Ccuenta {
    public CcuentaPasivo(){
        Super();
    }
    public void Super(){
        
    }
    public void haber(double cantidad){
        double pasivo=this.getSaldo();
        pasivo=pasivo+cantidad;
        this.setSaldo(pasivo);
    }
    public void debe(double cantidad){
        double pasivo=this.getSaldo();
        pasivo=pasivo-cantidad;
        this.setSaldo(pasivo);
    }
}
