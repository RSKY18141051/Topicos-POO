/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ContaZorrosA;

/**
 *
 * @author Kevin
 */
public class CcuentaCapital extends Ccuenta{
    public void haber(double cantidad){
        double capital=this.getSaldo();
        capital=capital+cantidad;
        this.setSaldo(capital);
    }
    public void debe(double cantidad){
        double capital=this.getSaldo();
        capital=capital-cantidad;
        this.setSaldo(capital);
    }
}
