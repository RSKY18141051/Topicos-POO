/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ContaZorrosA;

/**
 *
 * @author Kevin
 */
public class ClaseB extends ClaseA {
    protected int atributo_x02=1;
    public int metodo_x(){
        return atributo_x-10;
    }
    public int metodo_z(){
        atributo_x=super.metodo_x()+atributo_x+3;
        return super.metodo_x()+atributo_x;
    }
    protected void finalize()throws Throwable{
        System.out.println("recursos liberados de la claseB");
        super.finalize();
    }
}
